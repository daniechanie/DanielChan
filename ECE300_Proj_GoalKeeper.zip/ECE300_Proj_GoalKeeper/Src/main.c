/*****************************************************************************
 @Project		: ECE300 - Project - Goal Keeper
 @File 			: main.c
 @Details  	:
 @Author		: ldenissen
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0       			13 Aug 19  		Initial Release
   
******************************************************************************/

#include "Common.h"
#include "Hal.h"
#include "BSP.h"
#include "LED.h"
#include "IRQ.h"
#include "spim.h"
#include "LCD_ST7735R.h"
#include "gui.h"
#include <math.h>

/*****************************************************************************
 Define
******************************************************************************/
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10U
#define KEYPAD_UPDATE_MS	50U
#define BUZZ_SHORT 				50U			// Short buzz duration in Ms
#define BUZZ_LONG					200U		// Long buzz duration in Ms
#define BALL_UPDATE_MS		10U
#define BALL_SPEED				100000U		//smaller = faster
#define P1_SURFACE				11U
#define P2_SURFACE				101U
#define P1_LIFELINE				6U
#define P2_LIFELINE				106U
#define BALL_HALFWIDTH		3U
#define P_HALFWIDTH				15U
#define MOVE_RES					10U
#define ADC_UPDATE_MS			10U

/*****************************************************************************
 Type definition
******************************************************************************/

/*****************************************************************************
 Global Variables
******************************************************************************/
void GUI_AppDraw( BOOL bFrameStart );

/*****************************************************************************
 Local const Variables
******************************************************************************/

/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile BOOL	g_bSystemTick = FALSE;
static volatile BOOL	g_bSecTick = FALSE;
static int            g_nCount = 0;
static int            g_nBuzzerms = 0;
static volatile BOOL	g_bToggle = FALSE;
static unsigned int		g_nTimeSec = 0;
static volatile int 	g_bSpiDone = FALSE;
static SPIM_HANDLE		g_SpimHandle;
static GUI_DATA				g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV			g_MemDev;
static volatile BOOL 	g_bLCDUpdate = FALSE;
static volatile int 	g_nLCD = LCD_UPDATE_MS;
static volatile BOOL	g_bBacklightOn = TRUE;

static volatile BOOL 	g_bLcdFree  = TRUE;
static volatile int   g_nHIGH = 0;
static volatile int		g_nperiod = 0;
static volatile BOOL 	g_nKeypadScan = FALSE;
static volatile int 	g_nKeypad = KEYPAD_UPDATE_MS;

static volatile int 	g_nAdcUpdate = ADC_UPDATE_MS;
static volatile BOOL  g_bAdcUpdate = FALSE;
static float					g_nslidervalue = 0;
float 								g_nadcres = (3.3/4095);

static volatile BOOL	g_bcountstate = FALSE;
static volatile BOOL	g_bp1_wins = FALSE;
static volatile BOOL	g_bp2_wins = FALSE;
static volatile BOOL	g_bresult_DRAW = FALSE;
static volatile BOOL	g_bstartpage = FALSE;
static volatile BOOL	g_bp1contact = FALSE;
static volatile BOOL	g_bp2contact = TRUE;
static volatile BOOL	g_bslideractivate = FALSE;
static volatile BOOL 	g_bballUpdate = FALSE;
static volatile BOOL  g_btouchline = FALSE;
static volatile BOOL  g_bgameinit = FALSE;
static volatile BOOL  g_bp1p2lock = FALSE;
static volatile BOOL  g_bstartcountbeep = FALSE;
static volatile BOOL  g_bp1side = FALSE;
static volatile BOOL  g_bp2side = FALSE;
static volatile BOOL  g_bpause = FALSE; 
static volatile int 	g_nstartcounter = 0;
static volatile int 	g_ncountdownvalue = 3;
static volatile float	g_np1pos = 80;		// blue slider
static volatile float g_np2pos = 80;		// orange slider
static volatile float	g_nballpos_x = 74;
static volatile float	g_nballpos_y = 98;
static volatile int   g_nplayercounter = 0;
static volatile int		g_nballspeed = 0;
static volatile int		g_nballdelay = BALL_UPDATE_MS;
static volatile float	g_nballdx;
static volatile float	g_nballdy;
static volatile float	g_ntempballdx;
static volatile float	g_ntempballdy; 
static volatile float g_np1col_x;
static volatile float g_np1col_angle;
static volatile float	g_np2col_x;
static volatile float g_np2col_angle;


/*****************************************************************************
 Local Functions
******************************************************************************/
static void main_LcdInit( void );
static void main_KeyScan( void );
static void main_AdcInit( void );
static void main_Adcupdate( void );
static void ballupdate( void );
static void LED_update( void );
static void ballcol_update( void );
static void game_init( void );
/*****************************************************************************
 Implementation
******************************************************************************/
int main()
{
	Port_Init();
	SystemCoreClockUpdate ();
	SysTick_Config( SystemCoreClock/1000 );  
	
	/* SSI initialization */
	NVIC_SetPriority( GPIOF_IRQn, 1 );
	SpimInit(
		&g_SpimHandle,
		0U,
		25000000U,
		SPI_CLK_INACT_LOW,
		SPI_CLK_RISING_EDGE,
		SPI_DATA_SIZE_8 );
	
	main_LcdInit();
	main_AdcInit();
	IRQ_Init();
	
	for(;;)
  {
		/* LCD update */
		if( FALSE != g_bLCDUpdate )
		{
			if( 0 != g_bLcdFree )
			{
				g_bLCDUpdate = FALSE;
				g_bLcdFree = FALSE;
			  
				/* Draw every block. Consumes less time  */
				GUI_Draw_Exe(); 
			}
		}
		if( FALSE != g_nKeypadScan )
		{
			g_nKeypadScan = FALSE;
			main_KeyScan();
		}
		if(g_bAdcUpdate != FALSE && ADC0_BUSY() == 0)
		{
			g_bAdcUpdate = FALSE;
			main_Adcupdate();
		}
		game_init();
		if (g_bstartpage == TRUE && g_bcountstate == FALSE)	// if game starts
		{
			LED_update();
			ballcol_update();
			//ball movement update
			ballupdate();
		}
	}
}	
/*****************************************************************************
 Callback functions
******************************************************************************/
void SysTick_Handler( void )  
{
	g_bSystemTick = TRUE;
		
	/* Provide system tick */
  g_nCount++;
  if (g_nCount == 1000)
  {
    g_bSecTick = TRUE;
		g_nCount=0;
		if (g_bstartpage == TRUE && g_bcountstate == FALSE && g_nTimeSec < 60 && g_bpause == FALSE)
		{
			g_nTimeSec++;
		}
  }
	/*	countdown beep	*/
	if(g_bcountstate == TRUE)
	{
		if(g_bstartcountbeep == TRUE)
		{
			BUZZER_ON();
			g_nBuzzerms = BUZZ_SHORT;
			g_bstartcountbeep = FALSE;
		}
		g_bstartpage = TRUE;
		g_nstartcounter++;
		if ( g_nstartcounter == 1000 )
		{
			g_nBuzzerms = BUZZ_SHORT;
			g_ncountdownvalue--;
			g_nstartcounter = 0;
			if( 0 == g_ncountdownvalue )
			{	
				g_bcountstate = FALSE;
				g_ncountdownvalue = 3;
				g_nBuzzerms = BUZZ_LONG;
			}
			BUZZER_ON();
		}
	}
	/* ball speed */
	if( 0 != g_nballdelay )
	{
		g_nballdelay--;
		if( 0 == g_nballdelay )
		{
			g_nballdelay = BALL_UPDATE_MS;
			g_bballUpdate = TRUE;
		}
	}
	if( 0 != g_nLCD )
	{
		g_nLCD--;
		if( 0 == g_nLCD )
		{
			g_nLCD = LCD_UPDATE_MS;
			g_bLCDUpdate = TRUE;
		}
	}
	if( 0 != g_nKeypad )
	{
		g_nKeypad--;
		if( 0 == g_nKeypad )
		{
			g_nKeypad = KEYPAD_UPDATE_MS;
			g_nKeypadScan = TRUE;
		}
	}
	if( 0 != g_nBuzzerms)
	{
		g_nBuzzerms--;
		if( 0 == g_nBuzzerms )
		{
			BUZZER_OFF();
		}
	}
	if( 0 != g_nAdcUpdate )
	{
		g_nAdcUpdate--;
		if( 0 == g_nAdcUpdate )
		{
			g_bAdcUpdate = TRUE;
			g_nAdcUpdate = ADC_UPDATE_MS;
		}
	}
}

void GUI_AppDraw( BOOL bFrameStart )
{
	/* This function invokes from GUI library */
	char buf[128];
	if(g_bcountstate == FALSE && g_bstartpage == FALSE)
	{
		/* This function invokes from GUI library */
		GUI_Clear( ClrSteelBlue ); /* Set background to blue.Refer to gui.h */
		GUI_SetFont( &FONT_Arialbold16 );
		GUI_PrintString( "Goal Keeper Game", ClrDarkBlue , 12 , 8 );
		GUI_SetColor( ClrThistle );
		GUI_DrawFilledRect( 0, 30, 159, 128);
		GUI_SetFont( &FONT_Arialbold16 );
		GUI_PrintString( "Mission", ClrBlack , 55 , 38 );
		GUI_SetFont( &FONT_Arialbold12 );
		GUI_PrintString( "Force the ball past your enemy's line to WIN!", ClrBlack , 8 , 56 );
		GUI_SetFontBackColor( ClrMaroon );
		GUI_PrintString( "*Press SW1 to start!*", ClrBlack , 18 , 100 );
	}

	else if(g_bstartpage == TRUE )
	{
		GUI_Clear( ClrFloralWhite ); /* Set background to blue.Refer to gui.h */
		
		// goal keeper and line original position
		/*	(TOTAL)	width = 159, height = 128	*/
		if(g_bcountstate == TRUE )
		{
			GUI_Clear( ClrFloralWhite );
			GUI_SetFont( &FONT_Arialbold16 );
			GUI_SetFontBackColor( ClrBlue );
			GUI_PrintString( "Game starting in ...", ClrBlack , 8 , 50 );
			GUI_SetFont( &FONT_Arialbold24 );
			sprintf( buf, "%d", g_ncountdownvalue );
			GUI_PrintString( buf, ClrBlack, 68, 68 );
		}
		
		//left, right, up and down border
		GUI_SetColor( ClrBlack );
		GUI_DrawFilledRect( 3, 6, 4, P2_LIFELINE);
		GUI_DrawFilledRect( 156, 6, 157, P2_LIFELINE);
		
		//	player 1	 (top)
		GUI_SetColor( ClrMidnightBlue );
		GUI_DrawFilledRect( 4, 4, 156, P1_LIFELINE);
		GUI_DrawFilledRect( (g_np1pos - P_HALFWIDTH), P1_LIFELINE, (g_np1pos + P_HALFWIDTH), 11);
		
		//	player 2	(bottom)
		GUI_SetColor( ClrMaroon );
		GUI_DrawFilledRect( (g_np2pos - P_HALFWIDTH), P2_SURFACE, (g_np2pos + P_HALFWIDTH), P2_LIFELINE);
		GUI_DrawFilledRect( 4, P2_LIFELINE, 156, 108);

		
		//	ball (mayb can alternate ball starting point every reset?)
		if(g_bresult_DRAW == FALSE && g_nTimeSec < 60)
		{
			GUI_SetColor( ClrBlack );
			GUI_DrawFilledRect( (g_nballpos_x - BALL_HALFWIDTH), (g_nballpos_y - BALL_HALFWIDTH), (g_nballpos_x + BALL_HALFWIDTH), (g_nballpos_y + BALL_HALFWIDTH));
		}
		
		GUI_SetColor( ClrSkyBlue );
		GUI_DrawFilledRect( 0, 112, 159, 128);
		GUI_SetFont( &FONT_Arialbold12 );
		GUI_SetFontBackColor( ClrLightCyan );

		/* when game starts */
		if (g_bstartpage == TRUE && g_bcountstate == FALSE) 
		{
			if(g_bpause == TRUE && g_bp1_wins == FALSE && g_bp2_wins == FALSE && g_bresult_DRAW == FALSE)
			{
				GUI_PrintString( "Game Paused!", ClrBlack , 38 , 48 );
				GUI_PrintString( "Press SW1 to resume!", ClrBlack , 15 , 68 );
			}
			if(g_nTimeSec < 60 && g_bp1_wins == FALSE && g_bp2_wins == FALSE)
			{
				sprintf( buf, "%02u seconds remaining!", (60 - g_nTimeSec));
			}
			if(g_nTimeSec >= 50 && g_nTimeSec <= 60 )
			{
				GUI_PrintString( buf, ClrDarkRed, 14, 115 );
			}
			else if(g_nTimeSec < 50)
			{
				GUI_PrintString( buf, ClrBlack, 14, 115 );
			}	
			if (g_bp1_wins == TRUE)
			{
				GUI_SetFont( &FONT_Arialbold12 );
				GUI_PrintString( "Player 1 WINS!", ClrMidnightBlue , 36 , 48 );
				GUI_PrintString( "Press SW1 to play", ClrBlack , 25 , 68 );
				GUI_PrintString( "AGAIN!!", ClrBlack , 60 , 81 );
			}
			else if (g_bp2_wins == TRUE)
			{
				GUI_SetFont( &FONT_Arialbold12 );
				GUI_PrintString( "Player 2 WINS!", ClrMaroon , 36 , 48 );
				GUI_PrintString( "Press SW1 to play", ClrBlack , 25 , 68 );
				GUI_PrintString( "AGAIN!!", ClrBlack , 60 , 81 );
			}
			else if (g_bresult_DRAW == TRUE)
			{
				GUI_SetFont( &FONT_Arialbold12 );
				GUI_PrintString( "TIMES UP!" , ClrDarkRed, 54 , 115 );
				GUI_PrintString( "Too bad, its a DRAW!", ClrBlack , 18 , 48 );
				GUI_PrintString( "Press SW1 to play", ClrBlack , 25 , 68 );
				GUI_PrintString( "AGAIN!!", ClrBlack , 60 , 81 );
			}
		}
	}
}

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}

/*****************************************************************************
 Local functions
******************************************************************************/
static void main_KeyScan( void )
{
  int nRow, input;
	static BOOL bp1left = FALSE;
	static BOOL bp1right = FALSE;
	static BOOL bp2left = FALSE;
	static BOOL bp2right = FALSE;
	
  /* Set all rows to high so that if any key is pressed, 
     a falling edge on the column line can be detected */
  KEYPAD_ALL_ROWS_ON();

  for( nRow=0; nRow<4; nRow++ )
  {
    /* Pull row by row low to determined which button is pressed */
		if(nRow > 0)
		{
			KEYPAD_ROW_MASKED |= (1U << (nRow-1));
		}
    KEYPAD_ROW_MASKED &= ~(1U << nRow);
				
    /* Short delay to stabalize row that has just been pulled low */
    __nop(); __nop(); __nop();
		
    /* Read input */
    input = KEYPAD_COL_IN();	
		
		if(nRow == 0)
		{
			if((input & BIT(0)) == FALSE) // '1'
			{
				bp2left = TRUE;
			}
			if((input & BIT(2)) == FALSE)  // '3'
			{
				bp1right = TRUE;
			}
		}
		else if(nRow == 2)
		{
			if((input & BIT(0)) == FALSE) // '7'
			{
				bp2right = TRUE;
			}
			if((input & BIT(2)) == FALSE)  // '9'
			{
				bp1left = TRUE;
			}
		}
	}

	if(g_bp1p2lock == FALSE)
	{
		if(bp2left == TRUE)
		{
			bp2left = FALSE;	//reset movement
			if(g_np2pos >= 30)	// p2 move left
			{
				g_np2pos = g_np2pos - MOVE_RES;
				if(g_bcountstate == TRUE)
				{
					if((g_nplayercounter % 2) == 1 )
					{
						g_nballpos_x = g_nballpos_x - MOVE_RES;
					}
				}
			}
		}
		if(bp2right == TRUE)
		{
			bp2right = FALSE; //reset movement
			if(g_np2pos <= 130)	// p2 move right
			{
				g_np2pos = g_np2pos + MOVE_RES;
				if(g_bcountstate == TRUE)
				{
					if((g_nplayercounter % 2) == 1 )
					{
						g_nballpos_x = g_nballpos_x + MOVE_RES;
					}
				}
			}
		}
		if(bp1right == TRUE)
		{
			bp1right = FALSE;
			if(g_np1pos >= 30)	// p1 move right
			{
				g_np1pos = g_np1pos - MOVE_RES;
				if(g_bcountstate == TRUE)
				{
					if((g_nplayercounter % 2) == 0 )
					{
						g_nballpos_x = g_nballpos_x - MOVE_RES;
					}
				}
			}
		}
		if(bp1left == TRUE)
		{
			bp1left = FALSE;
			if(g_np1pos <= 130)	// p1 move left
			{
				g_np1pos = g_np1pos + MOVE_RES;
				if(g_bcountstate == TRUE)
				{
					if((g_nplayercounter % 2) == 0 )
					{
						g_nballpos_x = g_nballpos_x + MOVE_RES;
					}
				}
			}
		}		
	}
	/* Reset all rows for next key detection */
	KEYPAD_ALL_ROWS_OFF();
}

static void main_AdcInit()
{
	/** Set SS0 for AIN8, AIN9 **/
	ADC0->ACTSS &= ~ADC_ACTSS_ASEN0;/* Disable ADC while initializing */
	ADC0->EMUX |= ADC_EMUX_EM0_PROCESSOR; /* Set Processer as trigger */
	ADC0->SSMUX0 |= (0x08 << ADC_SSMUX0_MUX0_S); /* AIN8 for Seq. 0 */  
	ADC0->SSCTL0 &= ~(ADC_SSCTL0_D0 | ADC_SSCTL0_TS0);
	ADC0->SSCTL0 |= ADC_SSCTL0_END0;	/* Step 0 is END */
	ADC0->SAC |= ADC_SAC_AVG_32X; /* Set hardware averaging to 32X*/
	ADC0->IM |= ADC_IM_MASK0; //set SS0 as interrupt mask
	ADC0->ACTSS |= ADC_ACTSS_ASEN0; /* Enable ADC */

	ADC0_SS0_Start(); /* Start first measurement */
}

static void main_Adcupdate()
{
	uint16_t AIN8_result;		//digital values
	
	// READ ADC MEASUREMENTS
	AIN8_result = ADC0_GET_FIFO();  //slider			 (Step 0)
 	g_nslidervalue = (AIN8_result * 100 / 4095) + 1;
	/* Start next measurement */
	ADC0_SS0_Start();
}

static void main_LcdInit( void )
{
	int screenx;
	int screeny;
	
	/* g_SpimHandle shall be itializaed before use */
	
	/* Choosing a landscape orientation */
	LcdInit( &g_SpimHandle, LCD_LANDSCAPE );
	
	/* Get physical LCD size in pixels */
	LCD_GetSize( &screenx, &screeny );
	
	/* Initialize GUI */
	GUI_Init(
		&g_MemDev,
		screenx,
		screeny,
		g_aBuf,
		sizeof(g_aBuf) );
	
	/* Switch to transfer word for faster performance */
	SpimSetDataSize( &g_SpimHandle, SPI_DATA_SIZE_16 );
	GUI_16BitPerPixel( TRUE );
	
	/* Clear LCD screen to Blue */
	GUI_Clear( ClrBlue );

  /* set font color background */
  GUI_SetFontBackColor( ClrBisque );
    
  /* Set font */
	GUI_SetFont( &g_sFontCalibri10 );
	
	LCD_AddCallback( main_cbLcdTransferDone );
	
	GUI_AddCbFrameEnd( main_cbGuiFrameEnd );
	
	/* Backlight ON */
	LCD_BL_ON();
}

void ballupdate()
{
	g_nballspeed++;
	if(g_nballspeed > (BALL_SPEED / ((g_nslidervalue/2) + 8)))	//ball speed with slider adjustment
	{
		g_nballspeed = 0;
		if(g_bp1contact == TRUE)
		{
			//p1 top ball collision logic
			g_np1col_x = g_nballpos_x - g_np1pos;
			g_np1col_x = g_np1col_x / P_HALFWIDTH;		//percent of the degree of collision
			g_np1col_angle = g_np1col_x * (PI/3);
			g_nballdx = 3 * sin(g_np1col_angle);		// resolution multiplier (round down)
			g_nballdy = 3 * cos(g_np1col_angle);
		}
		else if(g_bp2contact == TRUE)
		{
			//p2 btm ball collision logic
			g_np2col_x = g_nballpos_x - g_np2pos;
			g_np2col_x = g_np2col_x / P_HALFWIDTH;		//percent of collision spot of the slider
			g_np2col_angle = g_np2col_x * (PI/3);
			g_nballdx = 3 * sin(g_np2col_angle);		// resolution multiplier (round down)
			g_nballdy = -3 * cos(g_np2col_angle);
		}
		if( (g_nballpos_x + BALL_HALFWIDTH) > 155 || (g_nballpos_x - BALL_HALFWIDTH) < 5 )
		{
			g_nballdx = g_nballdx * -1;
		}	

		if(g_btouchline == TRUE || g_bresult_DRAW)
		{
			g_nballdx = 0;
			g_nballdy = 0;
		}
		g_nballpos_x = g_nballpos_x + g_nballdx;
		g_nballpos_y = g_nballpos_y + g_nballdy;
	}
}

void LED_update()
{	
	/*	LED Conditions for slider		*/
	if(g_nslidervalue <=25)
	{
		LED_RGB_SET(RGB_GREEN);
	}
	else if(g_nslidervalue <=50)
	{
		LED_RGB_SET(RGB_BLUE);
	}
	else if(g_nslidervalue <=75)
	{
		LED_RGB_SET(RGB_YELLOW);
	}
	else if(g_nslidervalue >75)
	{
		LED_RGB_SET(RGB_RED);
	}
}
/*****************************************************************************
 Interrupt functions
******************************************************************************/

void GPIOF_Button_IRQHandler(uint32_t status)
{
	if(0 != (status & BIT(PF_SW1)))
	{
		if(g_bstartpage == TRUE && g_bcountstate == FALSE && g_bpause == FALSE 
			&& g_bp2_wins == FALSE && g_bp1_wins == FALSE && g_bresult_DRAW == FALSE)
		{
			g_bpause = TRUE;
			g_ntempballdx = g_nballdx;
			g_ntempballdy = g_nballdy;
			g_nballdx = 0;
			g_nballdy = 0;
			g_bp1p2lock = TRUE;
		}
		else if(g_bpause == TRUE && g_bcountstate == FALSE && g_bstartpage == TRUE
						&& g_bp2_wins == FALSE && g_bp1_wins == FALSE && g_bresult_DRAW == FALSE)
		{
			g_bp1p2lock = FALSE;
			g_bpause = FALSE;
			g_nballdx = g_ntempballdx;
			g_nballdy = g_ntempballdy;
		}
		else if(g_bp1_wins || g_bp2_wins || g_bresult_DRAW == TRUE || g_bstartpage == FALSE)
		{
			g_nplayercounter++;
			g_bgameinit = TRUE;
		}
		GPIOF->ICR = BIT(PF_SW1);
	}
  if(0 != (status & BIT(PF_SW2)))
	{
		GPIOF->ICR = BIT(PF_SW2);
	}
}

void ballcol_update()
{
	if((g_nballpos_y + BALL_HALFWIDTH) >= P2_SURFACE )	//if it reaches the player 2 btm end
	{
		if( ( (g_nballpos_x + BALL_HALFWIDTH) >= (g_np2pos - P_HALFWIDTH) ) && ( (g_nballpos_x - BALL_HALFWIDTH) <= (g_np2pos + P_HALFWIDTH) ))	//if out of p2 reach
		{
			g_bp1contact = FALSE;
			g_bp2contact = TRUE;
		}
	}
	
	else if((g_nballpos_y - BALL_HALFWIDTH) <= P1_SURFACE) //if it reaches the player 1 top end
	{
		if( ( (g_nballpos_x + BALL_HALFWIDTH) >= (g_np1pos - P_HALFWIDTH) ) && ( (g_nballpos_x - BALL_HALFWIDTH) <= (g_np1pos + P_HALFWIDTH) ))	//if out of p2 reach
		{
			g_bp1contact = TRUE;
			g_bp2contact = FALSE;
		}
	}
	else	// continue previous dx & dy
	{
		g_bp1contact = FALSE;
		g_bp2contact = FALSE;
	}
	
	if((g_nballpos_y + BALL_HALFWIDTH) >= P2_LIFELINE || (g_nballpos_y - BALL_HALFWIDTH) <= P1_LIFELINE )	// if touches life line
	{
		g_btouchline = TRUE;
		g_bp1p2lock = TRUE;
		if((g_nballpos_y + BALL_HALFWIDTH) >= P2_LIFELINE)
		{
			g_bp1_wins = TRUE;
		}
		else if((g_nballpos_y - BALL_HALFWIDTH) <= P1_LIFELINE)
		{
			g_bp2_wins = TRUE;
		}
	}
	if(g_bp1_wins == FALSE && g_bp2_wins == FALSE && g_nTimeSec == 60)
	{
		g_bresult_DRAW = TRUE;
		g_bp1p2lock = TRUE;
	}			
}

void game_init()
{
	if(g_bgameinit == TRUE)
	{
		g_bpause = FALSE;
		g_bp1p2lock = FALSE;
		g_btouchline = FALSE;
		g_bgameinit = FALSE;
		g_bp1_wins = FALSE;
		g_bp2_wins = FALSE;
		g_bresult_DRAW = FALSE;
		g_bcountstate = TRUE;
		g_bstartcountbeep = TRUE;
		g_nTimeSec = 0;
		/* ball alternate start position */
		if(g_nplayercounter % 2 == 1)
		{		
			g_nballpos_y = 98;
		}
		else
		{
			g_nballpos_y = 14;
		}
		g_nballpos_x = 74;
		g_np1pos = 80;
		g_np2pos = 80;		
	}
}
void ADC0_IRQHandler (uint32_t Status )
{
	if( 0 != (Status & ADC_RIS_INR0) ) 
	{
		/* ISR codes */
		ADC0->ISC |= ADC_ISC_IN0; /* clear intr */
	}
}
